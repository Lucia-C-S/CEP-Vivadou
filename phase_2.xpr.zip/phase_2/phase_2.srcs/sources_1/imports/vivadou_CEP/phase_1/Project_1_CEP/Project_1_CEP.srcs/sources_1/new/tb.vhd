library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity tb_top_board_VGA_interface_phase_1 is
end tb_top_board_VGA_interface_phase_1;


architecture Behavioral of tb_top_board_VGA_interface_phase_1 is

    ----------------------------------------------------------------
    -- COMPONENT UNDER TEST
    -- KEEPING THE ORIGINAL TOP-LEVEL INTERFACE
    ----------------------------------------------------------------

    component top_board_VGA_interface_phase_1
        Port (
            clk        : in  STD_LOGIC;
            CPU_RESETN : in  STD_LOGIC;

            SW15       : in  STD_LOGIC;
            SW14       : in  STD_LOGIC;

            SW         : in  STD_LOGIC_VECTOR(11 downto 0);

            LED        : out STD_LOGIC_VECTOR(9 downto 0);

            vsync_led  : out STD_LOGIC;
            vsync_os   : out STD_LOGIC;
            hsync_os   : out STD_LOGIC;

            VGA_hsync  : out STD_LOGIC;
            VGA_vsync  : out STD_LOGIC;

            VGA_R      : out STD_LOGIC_VECTOR(3 downto 0);
            VGA_G      : out STD_LOGIC_VECTOR(3 downto 0);
            VGA_B      : out STD_LOGIC_VECTOR(3 downto 0)
        );
    end component;


    ----------------------------------------------------------------
    -- INPUTS
    ----------------------------------------------------------------

    signal clk        : STD_LOGIC := '0';
    signal CPU_RESETN : STD_LOGIC := '0';

    signal SW15 : STD_LOGIC := '0';
    signal SW14 : STD_LOGIC := '1';

    -- SW(11 downto 0)
    --
    -- SW(3) = switch 3
    -- SW(2) = switch 2
    -- SW(1) = switch 1
    --
    -- The remaining switches are kept at 0.

    signal SW : STD_LOGIC_VECTOR(11 downto 0) := (others => '0');


    ----------------------------------------------------------------
    -- OUTPUTS
    ----------------------------------------------------------------

    signal LED : STD_LOGIC_VECTOR(9 downto 0);

    signal vsync_led : STD_LOGIC;
    signal vsync_os  : STD_LOGIC;
    signal hsync_os  : STD_LOGIC;

    signal VGA_hsync : STD_LOGIC;
    signal VGA_vsync : STD_LOGIC;

    signal VGA_R : STD_LOGIC_VECTOR(3 downto 0);
    signal VGA_G : STD_LOGIC_VECTOR(3 downto 0);
    signal VGA_B : STD_LOGIC_VECTOR(3 downto 0);


begin

    ----------------------------------------------------------------
    -- DEVICE UNDER TEST
    ----------------------------------------------------------------

    DUT : top_board_VGA_interface_phase_1
        port map (
            clk        => clk,
            CPU_RESETN => CPU_RESETN,

            SW15       => SW15,
            SW14       => SW14,

            SW         => SW,

            LED        => LED,

            vsync_led  => vsync_led,
            vsync_os   => vsync_os,
            hsync_os   => hsync_os,

            VGA_hsync  => VGA_hsync,
            VGA_vsync  => VGA_vsync,

            VGA_R      => VGA_R,
            VGA_G      => VGA_G,
            VGA_B      => VGA_B
        );


    ----------------------------------------------------------------
    -- 100 MHz CLOCK
    -- 10 ns period
    ----------------------------------------------------------------

    clk_process : process
    begin

        while true loop

            clk <= '0';
            wait for 5 ns;

            clk <= '1';
            wait for 5 ns;

        end loop;

    end process;


    ----------------------------------------------------------------
    -- STIMULUS
    ----------------------------------------------------------------

    stimulus : process
    begin

        ----------------------------------------------------------------
        -- INITIAL CONDITIONS
        ----------------------------------------------------------------

        CPU_RESETN <= '0';

        SW14 <= '1';       -- select ce_25MHz
        SW15 <= '0';       -- display hctr

        SW <= "000000000000";

        wait for 200 ns;


        ----------------------------------------------------------------
        -- RELEASE RESET
        ----------------------------------------------------------------

        CPU_RESETN <= '1';

        wait for 1 us;


        ----------------------------------------------------------------
        -- TEST SW14
        --
        -- SW14 = 0 -> ce_50Hz
        -- SW14 = 1 -> ce_25MHz
        ----------------------------------------------------------------

        SW14 <= '0';

        wait for 2 us;

        SW14 <= '1';

        wait for 2 us;


        ----------------------------------------------------------------
        -- TEST SW15
        --
        -- SW15 = 0 -> hctr on LEDs
        -- SW15 = 1 -> vctr on LEDs
        ----------------------------------------------------------------

        SW15 <= '0';

        wait for 2 us;

        SW15 <= '1';

        wait for 2 us;


        ----------------------------------------------------------------
        -- ============================================================
        -- COLOUR FSM
        -- ============================================================
        --
        -- Only SW(1), SW(2), SW(3) are used.
        --
        -- IMPORTANT:
        -- We use complete vectors so there are no multiple signal
        -- assignments fighting each other.
        --
        -- Expected sequences:
        --
        -- SW1 -> SW2 -> SW3 = S5  -> 001
        -- SW1 -> SW3 -> SW2 = S7  -> 010
        -- SW2 -> SW1 -> SW3 = S9  -> 011
        -- SW2 -> SW3 -> SW1 = S11 -> 100
        -- SW3 -> SW1 -> SW2 = S13 -> 101
        -- SW3 -> SW2 -> SW1 = S15 -> 110
        --
        ----------------------------------------------------------------


        ----------------------------------------------------------------
        -- RESET FSM
        ----------------------------------------------------------------

        CPU_RESETN <= '0';

        SW <= "000000000000";

        wait for 200 ns;

        CPU_RESETN <= '1';

        wait for 100 ns;


        ----------------------------------------------------------------
        -- SCHEME 1
        -- SW1 -> SW2 -> SW3
        -- Expected colour_scheme = 001
        ----------------------------------------------------------------

        -- SW1 ON
        SW <= "000000000010";
        wait for 100 ns;

        -- SW1 OFF, SW2 ON
        SW <= "000000000100";
        wait for 100 ns;

        -- SW2 OFF, SW3 ON
        SW <= "000000001000";
        wait for 100 ns;

        -- All OFF
        SW <= "000000000000";

        wait for 1 us;


        ----------------------------------------------------------------
        -- RESET
        ----------------------------------------------------------------

        CPU_RESETN <= '0';
        SW <= "000000000000";

        wait for 200 ns;

        CPU_RESETN <= '1';

        wait for 100 ns;


        ----------------------------------------------------------------
        -- SCHEME 2
        -- SW1 -> SW3 -> SW2
        -- Expected colour_scheme = 010
        ----------------------------------------------------------------

        -- SW1 ON
        SW <= "000000000010";
        wait for 100 ns;

        -- SW1 OFF, SW3 ON
        SW <= "000000001000";
        wait for 100 ns;

        -- SW3 OFF, SW2 ON
        SW <= "000000000100";
        wait for 100 ns;

        -- All OFF
        SW <= "000000000000";

        wait for 1 us;


        ----------------------------------------------------------------
        -- RESET
        ----------------------------------------------------------------

        CPU_RESETN <= '0';
        SW <= "000000000000";

        wait for 200 ns;

        CPU_RESETN <= '1';

        wait for 100 ns;


        ----------------------------------------------------------------
        -- SCHEME 3
        -- SW2 -> SW1 -> SW3
        -- Expected colour_scheme = 011
        ----------------------------------------------------------------

        -- SW2 ON
        SW <= "000000000100";
        wait for 100 ns;

        -- SW2 OFF, SW1 ON
        SW <= "000000000010";
        wait for 100 ns;

        -- SW1 OFF, SW3 ON
        SW <= "000000001000";
        wait for 100 ns;

        -- All OFF
        SW <= "000000000000";

        wait for 1 us;


        ----------------------------------------------------------------
        -- RESET
        ----------------------------------------------------------------

        CPU_RESETN <= '0';
        SW <= "000000000000";

        wait for 200 ns;

        CPU_RESETN <= '1';

        wait for 100 ns;


        ----------------------------------------------------------------
        -- SCHEME 4
        -- SW2 -> SW3 -> SW1
        -- Expected colour_scheme = 100
        ----------------------------------------------------------------

        -- SW2 ON
        SW <= "000000000100";
        wait for 100 ns;

        -- SW2 OFF, SW3 ON
        SW <= "000000001000";
        wait for 100 ns;

        -- SW3 OFF, SW1 ON
        SW <= "000000000010";
        wait for 100 ns;

        -- All OFF
        SW <= "000000000000";

        wait for 1 us;


        ----------------------------------------------------------------
        -- RESET
        ----------------------------------------------------------------

        CPU_RESETN <= '0';
        SW <= "000000000000";

        wait for 200 ns;

        CPU_RESETN <= '1';

        wait for 100 ns;


        ----------------------------------------------------------------
        -- SCHEME 5
        -- SW3 -> SW1 -> SW2
        -- Expected colour_scheme = 101
        ----------------------------------------------------------------

        -- SW3 ON
        SW <= "000000001000";
        wait for 100 ns;

        -- SW3 OFF, SW1 ON
        SW <= "000000000010";
        wait for 100 ns;

        -- SW1 OFF, SW2 ON
        SW <= "000000000100";
        wait for 100 ns;

        -- All OFF
        SW <= "000000000000";

        wait for 1 us;


        ----------------------------------------------------------------
        -- RESET
        ----------------------------------------------------------------

        CPU_RESETN <= '0';
        SW <= "000000000000";

        wait for 200 ns;

        CPU_RESETN <= '1';

        wait for 100 ns;


        ----------------------------------------------------------------
        -- SCHEME 6
        -- SW3 -> SW2 -> SW1
        -- Expected colour_scheme = 110
        ----------------------------------------------------------------

        -- SW3 ON
        SW <= "000000001000";
        wait for 100 ns;

        -- SW3 OFF, SW2 ON
        SW <= "000000000100";
        wait for 100 ns;

        -- SW2 OFF, SW1 ON
        SW <= "000000000010";
        wait for 100 ns;

        -- All OFF
        SW <= "000000000000";

        wait for 1 us;


        ----------------------------------------------------------------
        -- END
        ----------------------------------------------------------------

        wait;

    end process;

end Behavioral;

